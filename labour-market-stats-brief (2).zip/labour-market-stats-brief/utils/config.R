# reference months - change these for each release

manual_month <- "jan2026"
manual_month_hr1 <- "dec2025"

manual_month <- tolower(manual_month)
manual_month_hr1 <- tolower(manual_month_hr1)

# reference periods for comparisons
COVID_LFS_LABEL <- "Dec-Feb 2020"
COVID_VAC_LABEL <- "Jan-Mar 2020"
ELECTION_LABEL <- "Apr-Jun 2024"
