# app.R -------------------------------------------------------

# Core packages
library(shiny)
library(bslib)
library(dplyr)
library(stringr)
library(lubridate)
library(ggplot2)
library(plotly)
library(DBI)
library(RPostgres)
library(pool)
library(dbplyr)
library(shinyGovstyle)
library(rlang)
library(shiny.router)
library(shinyWidgets)
library(DT)
library(reactable)
library(dbtplotr)

`%||%` <- function(x, y) if (!is.null(x)) x else y

# Create single environment for whole app
app_env <- environment()

# DB pool (matches main branch pattern)
APP_DB <- new.env(parent = emptyenv())
APP_DB$pool <- pool::dbPool(
  drv      = RPostgres::Postgres(),
  host     = Sys.getenv("PGHOST"),
  port     = Sys.getenv("PGPORT"),
  dbname   = Sys.getenv("PGDATABASE"),
  user     = Sys.getenv("PGUSER"),
  password = Sys.getenv("PGPASSWORD")
)

shiny::onStop(function() {
  pool::poolClose(APP_DB$pool)
})

# ------------------------------------------------------------
# Source internal helpers
# ------------------------------------------------------------
source("R/components/ggplot_DIT.r", local = app_env)
source("R/components/govuk_helpers.R", local = app_env)
source("R/components/govuk_header.R", local = app_env)
source("R/components/govuk_top_nav.R", local = app_env)
source("R/components/govuk_visuals.R", local = app_env)
source("R/components/govuk_page.R", local = app_env)
source("R/components/lfs_scripts.R", local = app_env)
source("R/components/employment_page_card_dbplyr.R", local = app_env)
source("R/components/employment_age_card_dbplyr.R", local = app_env)

# ------------------------------------------------------------
# Inputs
# ------------------------------------------------------------

tabs <- c(Home = "home", Employment = "employment", Unemployment = "unemployment", Vacancies = "vacancies")
default_route <- "home"
style <- "DBT"

# LFS table list used by Employment page controls
lfs_tables_full <- get_latest_lfs_table_list(APP_DB$pool)

# ------------------------------------------------------------
# Source page modules
# ------------------------------------------------------------
source("R/pages/page_home.R", local = app_env)
source("R/pages/page_employment.R", local = app_env)
source("R/pages/page_unemployment.R", local = app_env)
source("R/pages/page_vacancies.R", local = app_env)

# ------------------------------------------------------------
# 404 page UI
# ------------------------------------------------------------
page_404_ui <- tags$div(
  class = "govuk-width-container",
  tags$main(
    class = "govuk-main-wrapper",
    tags$h1(class = "govuk-heading-l", "Page not found"),
    tags$p(class = "govuk-body", "Use the navigation to choose a page."),
    tags$a(class = "govuk-link", href = paste0("#/", default_route), "Back to Home")
  )
)

# ------------------------------------------------------------
# UI
# ------------------------------------------------------------

ui <- fluidPage(
  govuk_apply_rebrand(),
  govuk_head_assets(),
  govuk_dependencies(style = style),

  tags$div(
    class = "govuk-template",

    govuk_header(
      service_name = "Labour Markets Dashboard",
      style = style,
      home_href = if (style == "GOVUK") "https://www.gov.uk/" else "https://data.trade.gov.uk/",
      service_href = paste0("#!/", default_route)
    ),

    uiOutput("topnav"),

    router_ui(
      route("/",            home_ui("home")),
      route("home",         home_ui("home")),
      route("employment",   employment_ui("employment")),
      route("unemployment", unemployment_ui("unemployment")),
      route("vacancies",    vacancies_ui("vacancies")),
      page_404 = page_404_ui
    ),

    footer(TRUE)
  )
)

# ------------------------------------------------------------
# Server
# ------------------------------------------------------------
server <- function(input, output, session) {
  router_server()

  observeEvent(session$clientData$url_hash, {
    route <- sub("^#!/?", "", session$clientData$url_hash)
    sel <- if (!nzchar(route)) "home" else route

    output$topnav <- renderUI({
      govuk_top_nav(tabs, selected = sel, id_prefix = "nav")
    })
  })

  home_server("home")
  employment_server("employment")
  unemployment_server("unemployment")
  vacancies_server("vacancies")
}

shinyApp(ui, server)
