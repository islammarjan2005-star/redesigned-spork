#' Create a GOV.UK or DBT branded header for a Shiny app
#'
#' Generates a responsive GOV.UK-style header with optional DBT branding.
#' Includes logo, service name, and links. The header uses GOV.UK Frontend
#' classes and can be customised for DBT styling.
#'
#' @param home_href Character. URL for the homepage link (logo click).
#'   Defaults to `"#"`.
#' @param service_name Character. Optional service name text displayed next
#'   to the logo. Defaults to `NULL` (no service name).
#' @param service_href Character. URL for the service name link.
#'   Defaults to `"#"`.
#' @param service_size Character. CSS font-size for the service name.
#'   Defaults to `"1.7rem"`.
#' @param style Character. Which branding style to use: `"GOVUK"` or `"DBT"`.
#'   Defaults to `"GOVUK"`.
#' @param dbt_logo_src Character. Path to DBT logo image (in `www/`).
#'   Defaults to `"DBT_white_cropped.png"`.
#' @param dbt_logo_alt Character. Alt text for DBT logo.
#'   Defaults to `"Department for Business and Trade"`.
#' @param height Numeric. Logo height in pixels. Defaults to `60`.
#'
#' @return A `<header>` tag containing GOV.UK or DBT branding elements.
#'
#' @examples
#' # GOV.UK header with service name
#' govuk_header(service_name = "Labour Market Dashboard",
#'              service_href = "/dashboard")
#'
#' # DBT branded header
#' govuk_header(style = "DBT", home_href = "/", service_name = "Data Explorer")
#'
#' @export

govuk_header <- function(
  home_href    = "#",
  service_name = NULL,
  service_href = "#",
  service_size = "1.7rem",
  style        = c("GOVUK", "DBT"),
  dbt_logo_src = "DBT_white_cropped.png",
  dbt_logo_alt = "Department for Business and Trade",
  height       = 60
) {
  style <- match.arg(style)

  logo_block <- if (style == "DBT") {
    # DBT variant: fix link height and force image height (belt-and-braces)
    tags$div(
      class = "govuk-header__logo",
      tags$a(
        href  = home_href,
        class = "govuk-header__link govuk-header__link--homepage",
        style = sprintf("display:inline-flex; align-items:center; height:%dpx; line-height:%dpx;", height, height),
        tags$img(
          src    = dbt_logo_src,
          alt    = dbt_logo_alt,
          class  = "govuk-header__logotype",
          # inline style wins against generic img rules
          style  = sprintf("height:%dpx; width:auto; max-width:none;", height)
        )
      )
    )
  } else {
    # GOV.UK crown 
    tags$div(
      class = "govuk-header__logo",
      tags$a(
        href = home_href,
        class = "govuk-header__link govuk-header__link--homepage",
        tags$svg(
          focusable = "false",
          role = "img",
          xmlns = "http://www.w3.org/2000/svg",
          viewBox = "0 0 324 60",
          height = "30",
          width  = "162",
          fill   = "currentcolor",
          class  = "govuk-header__logotype",
          `aria-label` = "GOV.UK",
          tags$title("GOV.UK"),
          tags$g(
            tags$circle(cx = "20",   cy = "17.6", r = "3.7"),
            tags$circle(cx = "10.2", cy = "23.5", r = "3.7"),
            tags$circle(cx = "3.7",  cy = "33.2", r = "3.7"),
            tags$circle(cx = "31.7", cy = "30.6", r = "3.7"),
            tags$circle(cx = "43.3", cy = "17.6", r = "3.7"),
            tags$circle(cx = "53.2", cy = "23.5", r = "3.7"),
            tags$circle(cx = "59.7", cy = "33.2", r = "3.7"),
            tags$circle(cx = "31.7", cy = "30.6", r = "3.7"),
            tags$path(d = "M33.1,9.8c.2-.1.3-.3.5-.5l4.6,2.4v-6.8l-4.6,1.5c-.1-.2-.3-.3-.5-.5l1.9-5.9h-6.7l1.9,5.9c-.2.1-.3.3-.5.5l-4.6-1.5v6.8l4.6-2.4c.1.2.3.3.5.5l-2.6,8c-.9,2.8,1.2,5.7,4.1,5.7h0c3,0,5.1-2.9,4.1-5.7l-2.6-8ZM37,37.9s-3.4,3.8-4.1,6.1c2.2,0,4.2-.5,6.4-2.8l-.7,8.5c-2-2.8-4.4-4.1-5.7-3.8.1,3.1.5,6.7,5.8,7.2,3.7.3,6.7-1.5,7-3.8.4-2.6-2-4.3-3.7-1.6-1.4-4.5,2.4-6.1,4.9-3.2-1.9-4.5-1.8-7.7,2.4-10.9,3,4,2.6,7.3-1.2,11.1,2.4-1.3,6.2,0,4,4.6-1.2-2.8-3.7-2.2-4.2.2-.3,1.7.7,3.7,3,4.2,1.9.3,4.7-.9,7-5.9-1.3,0-2.4.7-3.9,1.7l2.4-8c.6,2.3,1.4,3.7,2.2,4.5.6-1.6.5-2.8,0-5.3l5,1.8c-2.6,3.6-5.2,8.7-7.3,17.5-7.4-1.1-15.7-1.7-24.5-1.7h0c-8.8,0-17.1.6-24.5,1.7-2.1-8.9-4.7-13.9-7.3-17.5l5-1.8c-.5,2.5-.6,3.7,0,5.3.8-.8,1.6-2.3,2.2-4.5l2.4,8c-1.5-1-2.6-1.7-3.9-1.7,2.3,5,5.2,6.2,7,5.9,2.3-.4,3.3-2.4,3-4.2-.5-2.4-3-3.1-4.2-.2-2.2-4.6,1.6-6,4-4.6-3.7-3.7-4.2-7.1-1.2-11.1,4.2,3.2,4.3,6.4,2.4,10.9,2.5-2.8,6.3-1.3,4.9,3.2-1.8-2.7-4.1-1-3.7,1.6.3,2.3,3.3,4.1,7,3.8,5.4-.5,5.7-4.2,5.8-7.2-1.3-.2-3.7,1-5.7,3.8l-.7-8.5c2.2,2.3,4.2,2.7,6.4,2.8-.7-2.3-4.1-6.1-4.1-6.1h10.6,0Z")
          ),
          tags$circle(class = "govuk-logo-dot", cx = "226", cy = "36", r = "7.3"),
          tags$path(d = "M93.94 41.25c.4 1.81 1.2 3.21 2.21 4.62 1 1.4 2.21 2.41 3.61 3.21s3.21 1.2 5.22 1.2 3.61-.4 4.82-1c1.4-.6 2.41-1.4 3.21-2.41.8-1 1.4-2.01 1.61-3.01s.4-2.01.4-3.01v.14h-10.86v-7.02h20.07v24.08h-8.03v-5.56c-.6.8-1.38 1.61-2.19 2.41-.8.8-1.81 1.2-2.81 1.81-1 .4-2.21.8-3.41 1.2s-2.41.4-3.81.4a18.56 18.56 0 0 1-14.65-6.63c-1.6-2.01-3.01-4.41-3.81-7.02s-1.4-5.62-1.4-8.83.4-6.02 1.4-8.83a20.45 20.45 0 0 1 19.46-13.65c3.21 0 4.01.2 5.82.8 1.81.4 3.61 1.2 5.02 2.01 1.61.8 2.81 2.01 4.01 3.21s2.21 2.61 2.81 4.21l-7.63 4.41c-.4-1-1-1.81-1.61-2.61-.6-.8-1.4-1.4-2.21-2.01-.8-.6-1.81-1-2.81-1.4-1-.4-2.21-.4-3.61-.4-2.01 0-3.81.4-5.22 1.2-1.4.8-2.61 1.81-3.61 3.21s-1.61 2.81-2.21 4.62c-.4 1.81-.6 3.71-.6 5.42s.8 5.22.8 5.22Zm57.8-27.9c3.21 0 6.22.6 8.63 1.81 2.41 1.2 4.82 2.81 6.62 4.82S170.2 24.39 171 27s1.4 5.62 1.4 8.83-.4 6.02-1.4 8.83-2.41 5.02-4.01 7.02-4.01 3.61-6.62 4.82-5.42 1.81-8.63 1.81-6.22-.6-8.63-1.81-4.82-2.81-6.42-4.82-3.21-4.41-4.01-7.02-1.4-5.62-1.4-8.83.4-6.02 1.4-8.83 2.41-5.02 4.01-7.02 4.01-3.61 6.42-4.82 5.42-1.81 8.63-1.81Zm0 36.73c1.81 0 3.61-.4 5.02-1s2.61-1.81 3.61-3.01 1.81-2.81 2.21-4.41c.4-1.81.8-3.61.8-5.62 0-2.21-.2-4.21-.8-6.02s-1.2-3.21-2.21-4.62c-1-1.2-2.21-2.21-3.61-3.01s-3.21-1-5.02-1-3.61.4-5.02 1c-1.4.8-2.61 1.81-3.61 3.01s-1.81 2.81-2.21 4.62c-.4 1.81-.8 3.61-.8 5.62 0 2.41.2 4.21.8 6.02.4 1.81 1.2 3.21 2.21 4.41s2.21 2.21 3.61 3.01c1.4.8 3.21 1 5.02 1Zm36.32 7.96-12.24-44.15h9.83l8.43 32.77h.4l8.23-32.77h9.83L200.3 58.04h-12.24Zm74.14-7.96c2.18 0 3.51-.6 3.51-.6 1.2-.6 2.01-1 2.81-1.81s1.4-1.81 1.81-2.81a13 13 0 0 0 .8-4.01V13.9h8.63v28.15c0 2.41-.4 4.62-1.4 6.62-.8 2.01-2.21 3.61-3.61 5.02s-3.41 2.41-5.62 3.21-4.62 1.2-7.02 1.2-5.02-.4-7.02-1.2c-2.21-.8-4.01-1.81-5.62-3.21s-2.81-3.01-3.61-5.02-1.4-4.21-1.4-6.62V13.9h8.63v26.95c0 1.61.2 3.01.8 4.01.4 1.2 1.2 2.21 2.01 2.81.8.8 1.81 1.4 2.81 1.81 0 0 1.34.6 3.51.6Zm34.22-36.18v18.92l15.65-18.92h10.82l-15.03 17.32 16.03 26.83h-10.21l-11.44-20.21-5.62 6.22v13.99h-8.83V13.9")
 
        )
      )
    )
  }

  service_block <- if (!is.null(service_name)) {
    tags$div(
      class = "govuk-header__content",
      tags$a(
        href  = service_href,
        class = "govuk-header__link govuk-header__service-name",
        style = paste0("font-size:", service_size, ";"),
        service_name
      )
    )
  } else NULL

  tags$header(
    class = "govuk-header govuk-header--full-width-border",
    `data-module` = "govuk-header",
    tags$div(
      class = "govuk-header__container govuk-width-container",
      style = "display:flex; align-items:center;",
      logo_block,
      service_block
    )
  )
}

