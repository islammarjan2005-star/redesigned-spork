### EMPLOYMENT BY AGE (DBPLYR CARD) ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

# UI ----
employment_age_stats_card_ui <- function(id) {
  ns <- NS(id)

  mod_govuk_data_vis_card_ui(
    id = ns("age_trend_card"),
    title = "Employment by age group",
    help_text = "Employment levels by age group (stacked). Source: ONS Labour Market tables (age group series codes).",
    table_content  = reactableOutput(ns("age_table"), height = "350px"),
    visual_content = plotlyOutput(ns("age_plot"),  height = "350px"),
    query = ns("sql_query"),

    controls = list(
      mod_quick_date_range_ui(
        id = ns("age_dates"),
        label_quick = "Time period",
        label_picker  = "Time period",
        custom_picker = "slider",
        presets = c("custom", "ytd", "past_year", "3y", "5y", "none")
      ),
      mod_filter_picker_ui(
        id                   = ns("age_filter"),
        label                = "Age groups",
        multiple             = TRUE,
        actions_box          = TRUE,
        live_search          = TRUE,
        virtual_scroll       = 10,
        selected_text_format = "count > 2"
      )
    ),

    accordion_controls = list(
      shinyWidgets::radioGroupButtons(
        inputId = ns("chart_type"),
        label   = "Chart type",
        choices = c("Stacked area" = "stacked_area",
                    "Stacked bar"  = "stacked_bar",
                    "Lines"        = "line"),
        justified = TRUE,
        status    = "danger",
        size      = "sm"
      ),
      conditionalPanel(
        condition = sprintf("input['%s'] == 'stacked_bar'", ns("chart_type")),
        shinyWidgets::sliderTextInput(
          inputId = ns("stack_mode"),
          label   = "Time interval between bars",
          choices = c("monthly","quarterly","annually","5year","decade"),
          selected = "quarterly",
          grid = TRUE
        )
      ),
      mod_annotation_line_ui(ns("date_lines"),
        type = "date", title = "Add key dates",
        add_label = "Add key date", show_delete = TRUE, auto_mask_date = TRUE
      ),
      mod_annotation_line_ui(ns("value_lines"),
        type = "value", title = "Add key values",
        add_label = "Add key values", show_delete = TRUE, auto_mask_date = TRUE
      )
    )
  )
}


# SERVER ----
employment_age_stats_card_server <- function(id, conn = APP_DB$pool) {
  moduleServer(id, function(input, output, session) {

    shinyWidgets::updateRadioGroupButtons(session, "chart_type", selected = "stacked_bar")
    date_lines  <- mod_annotation_line_server("date_lines",  type = "date")
    value_lines <- mod_annotation_line_server("value_lines", type = "value")

    # Series codes (employment levels for age groups used in your stacked chart)
    codes <- reactive(c("YBTO", "YBTR", "YBTU", "YBTX", "LF26", "LFK4"))

    # Base cleaned view (lazy)
    cleaned_tbl <- reactive({
      get_employment_age_tbl(codes())
    }) %>% bindCache(codes())

    # Picker + dates
    age <- mod_filter_picker_server(
      id       = "age_filter",
      data_tbl = cleaned_tbl,
      column   = "age_group",
      defaults_pretty = c("16-17", "18-24", "25-34", "35-49", "50-64", "65+")
    )

    dates <- mod_quick_date_range_server(
      id        = "age_dates",
      data_tbl  = cleaned_tbl,
      presets   = c("custom", "ytd", "past_year", "3y", "5y", "none"),
      default   = "5y",
      frequency = "quarterly",
      custom_picker = "slider",
      preserve_selection = TRUE
    )

    dat <- reactive({
      dr <- dates$date_range()
      date_from <- if (!is.null(dr) && length(dr) == 2) as.Date(dr[[1]]) else NULL
      date_to   <- if (!is.null(dr) && length(dr) == 2) as.Date(dr[[2]]) else NULL
      vals      <- age$selected()

      t <- cleaned_tbl() %>%
        apply_filters_general(
          date_col  = "time_period",
          date_from = date_from,
          date_to   = date_to,
          where_in  = list(age_group = vals)
        )

      list(
        data = t %>% dplyr::collect(),
        sql  = sql_render_pool_safe(t)
      )
    })

    output$age_table <- reactable::renderReactable({
      out <- dat(); req(nrow(out$data) > 0)
      reactable::reactable(out$data, sortable = TRUE, filterable = TRUE, resizable = TRUE,
                           pagination = TRUE, highlight = TRUE, striped = TRUE)
    })

    output$sql_query <- renderText({ dat()$sql })

    output$age_plot <- plotly::renderPlotly({
      out <- dat(); req(nrow(out$data) > 0)

      df <- out$data

      # Keep a stable order in stacked legend
      group_order_vec <- c("16-17","18-24","25-34","35-49","50-64","65+")

      if (identical(input$chart_type, "line")) {
        # Total across selected age groups
        df_total <- df %>%
          dplyr::group_by(time_period) %>%
          dplyr::summarise(value = sum(value, na.rm = TRUE), .groups = "drop") %>%
          dplyr::mutate(age_group = "Total")

        dbt_ts_plot(
          df_total,
          chart_type = "line",
          x_title = "Time period",
          y_title = "Employment (000s)",
          palette = dbt_palettes$gaf,
          initial_legend_mode = "hidden",
          group_col = "age_group",
          vlines = date_lines$values_out(), vline_labels = date_lines$labels_out(),
          hlines = value_lines$values_out(), hline_labels = value_lines$labels_out()
        )
      } else {
        dbt_ts_plot(
          df,
          chart_type = input$chart_type %||% "stacked_area",
          bar_interval = input$stack_mode,
          bar_agg      = "last",
          x_title = "Time period",
          y_title = "Employment (000s)",
          palette = dbt_palettes$gaf,
          initial_legend_mode = "hidden",
          group_col = "age_group",
          group_order = group_order_vec,
          vlines = date_lines$values_out(), vline_labels = date_lines$labels_out(),
          hlines = value_lines$values_out(), hline_labels = value_lines$labels_out()
        )
      }
    })
  })
}


# DATA ----
get_employment_age_tbl <- function(codes) {
  stopifnot(is.character(codes), length(codes) >= 1L)

  base <- dplyr::tbl(APP_DB$pool, dbplyr::in_schema("ons", "labour_market__age_group"))

  # time_period strings are typically rolling quarters like "Jun-Aug 2025".
  # Parse robustly in SQL:
  # - "Jun-Aug 2025" -> "Aug 2025"
  # - "Jun 2025"     -> "Jun 2025"
  # - "Q1 2025" / "2025 Q1" -> quarter end month
  clean_tp <- dbplyr::sql("btrim(regexp_replace(time_period::text, '\\s+', ' ', 'g'))")

  period_sql <- dbplyr::sql(paste0("
    (
      case
        -- Rolling quarters like Jun-Aug 2025 (use end month)
        when ", clean_tp, " ~ '^[A-Za-z]{3}-[A-Za-z]{3} [0-9]{4}$' then
          to_date(
            initcap(split_part(split_part(", clean_tp, ", ' ', 1), '-', 2))
            || ' ' || regexp_replace(", clean_tp, ", '.*([0-9]{4})$', '\\1'),
            'Mon YYYY'
          )

        -- Single month like Jun 2025
        when ", clean_tp, " ~ '^[A-Za-z]{3} [0-9]{4}$' then
          to_date(
            initcap(split_part(", clean_tp, ", ' ', 1))
            || ' ' || split_part(", clean_tp, ", ' ', 2),
            'Mon YYYY'
          )

        -- Quarter formats like Q1 2025 / 2025 Q1 (use quarter end month)
        when ", clean_tp, " ~ 'Q[1-4]' then
          to_date(
            (
              case
                when ", clean_tp, " ~ 'Q1' then 'Mar'
                when ", clean_tp, " ~ 'Q2' then 'Jun'
                when ", clean_tp, " ~ 'Q3' then 'Sep'
                when ", clean_tp, " ~ 'Q4' then 'Dec'
                else null
              end
            )
            || ' ' || regexp_replace(", clean_tp, ", '.*([0-9]{4}).*$', '\\1'),
            'Mon YYYY'
          )

        -- Fallback: try to extract "Mon YYYY" anywhere in string
        else
          to_date(
            initcap(regexp_replace(", clean_tp, ", '.*?([A-Za-z]{3})[^0-9]*([0-9]{4}).*', '\\1 \\2')),
            'Mon YYYY'
          )
      end
    )::date
  "))

  base %>%
    dplyr::filter(.data$dataset_indentifier_code %in% !!codes) %>%
    dplyr::mutate(time_period = !!period_sql) %>%
    dplyr::mutate(
      age_group = dplyr::case_when(
        .data$dataset_indentifier_code == "YBTO" ~ "16-17",
        .data$dataset_indentifier_code == "YBTR" ~ "18-24",
        .data$dataset_indentifier_code == "YBTU" ~ "25-34",
        .data$dataset_indentifier_code == "YBTX" ~ "35-49",
        .data$dataset_indentifier_code == "LF26" ~ "50-64",
        .data$dataset_indentifier_code == "LFK4" ~ "65+",
        TRUE ~ NA_character_
      )
    ) %>%
    dplyr::transmute(
      time_period,
      age_group,
      dataset_id = .data$dataset_indentifier_code,
      value = as.numeric(.data$value) / 1000
    )
}

### ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
